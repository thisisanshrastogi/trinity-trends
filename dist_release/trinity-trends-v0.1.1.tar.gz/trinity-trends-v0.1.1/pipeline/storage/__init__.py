# Storage module init
