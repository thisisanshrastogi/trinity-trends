"""
Test script to run the full pipeline step-by-step and save the output
of EVERY stage into a single debug JSON file.
"""

import json
import logging
from pathlib import Path
from pydantic import BaseModel
import time

from pipeline import config
from pipeline.models import CollectionScored
from pipeline.stages.s0_normalize import normalize
from pipeline.stages.s1_relevance import relevance_filter, get_embeddings
from pipeline.stages.s2_rerank import rerank
from pipeline.stages.s3_dedup import dedup_and_diversify
from pipeline.stages.s4_cluster import cluster
from pipeline.stages.s5_extract import extract_signals
from pipeline.stages.s6_merge import merge_signals
from pipeline.stages.s7_score import score_signals
from pipeline.stages.s8_compress import compress
from pipeline.stages.s9_synthesize import synthesize_trends

# Set up logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logging.getLogger("httpx").setLevel(logging.WARNING)

def pydantic_to_dict(obj):
    if isinstance(obj, list):
        return [pydantic_to_dict(o) for o in obj]
    if isinstance(obj, dict):
        return {k: pydantic_to_dict(v) for k, v in obj.items()}
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    return obj

def run_debug_test():
    input_path = config.INPUT_FILE
    output_path = Path("output/pipeline-debug.json")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    stage_results = {}
    
    # ── Load Input ───────────────────────────────────────────────────────
    logging.info(f"Loading input from {input_path}")
    with open(input_path) as f:
        raw = json.load(f)
    data = CollectionScored(**raw)
    seed_query = data.seed
    queries = [r.query for r in data.results]
    
    stage_results["input_seed"] = seed_query

    # ── Stage 0: Normalize ───────────────────────────────────────────────
    t0 = time.time()
    normalized = normalize(data)
    stage_results["stage_0_normalize"] = {
        "time_taken_sec": round(time.time() - t0, 2),
        "count": len(normalized),
        "results": pydantic_to_dict(normalized)
    }
    if not normalized: return

    # ── Stage 1: Relevance ───────────────────────────────────────────────
    t1 = time.time()
    scored = relevance_filter(normalized, queries)
    stage_results["stage_1_relevance"] = {
        "time_taken_sec": round(time.time() - t1, 2),
        "count": len(scored),
        "results": pydantic_to_dict(scored)
    }
    if not scored: return

    # ── Stage 2: Rerank ──────────────────────────────────────────────────
    t2 = time.time()
    reranked = rerank(scored, seed_query)
    stage_results["stage_2_rerank"] = {
        "time_taken_sec": round(time.time() - t2, 2),
        "count": len(reranked),
        "results": pydantic_to_dict(reranked)
    }

    # Embeddings for next stages
    embeddings = get_embeddings(reranked)

    # ── Stage 3: Dedup ───────────────────────────────────────────────────
    t3 = time.time()
    deduped, deduped_embeddings = dedup_and_diversify(reranked, embeddings)
    stage_results["stage_3_dedup"] = {
        "time_taken_sec": round(time.time() - t3, 2),
        "count": len(deduped),
        "results": pydantic_to_dict(deduped)
    }

    # ── Stage 4: Cluster ─────────────────────────────────────────────────
    t4 = time.time()
    all_clustered, clusters = cluster(deduped, deduped_embeddings)
    stage_results["stage_4_cluster"] = {
        "time_taken_sec": round(time.time() - t4, 2),
        "cluster_count": len(clusters),
        "results": {str(k): pydantic_to_dict(v) for k, v in clusters.items()}
    }

    # ── Stage 5: Extract ─────────────────────────────────────────────────
    t5 = time.time()
    extracted = extract_signals(clusters, seed_query)
    stage_results["stage_5_extract"] = {
        "time_taken_sec": round(time.time() - t5, 2),
        "count": len(extracted),
        "results": pydantic_to_dict(extracted)
    }

    # ── Stage 6: Merge ───────────────────────────────────────────────────
    t6 = time.time()
    merged = merge_signals(extracted)
    stage_results["stage_6_merge"] = {
        "time_taken_sec": round(time.time() - t6, 2),
        "count": len(merged),
        "results": pydantic_to_dict(merged)
    }

    # ── Stage 7: Score ───────────────────────────────────────────────────
    t7 = time.time()
    scored_signals = score_signals(merged)
    stage_results["stage_7_score"] = {
        "time_taken_sec": round(time.time() - t7, 2),
        "count": len(scored_signals),
        "results": pydantic_to_dict(scored_signals)
    }

    # ── Stage 8: Compress ────────────────────────────────────────────────
    t8 = time.time()
    compressed = compress(scored_signals, seed_query, total_evidence=len(normalized))
    stage_results["stage_8_compress"] = {
        "time_taken_sec": round(time.time() - t8, 2),
        "results": pydantic_to_dict(compressed)
    }

    # ── Stage 9: Synthesize ──────────────────────────────────────────────
    t9 = time.time()
    synthesized = synthesize_trends(compressed, min_score=0.0)
    stage_results["stage_9_synthesize"] = {
        "time_taken_sec": round(time.time() - t9, 2),
        "results": pydantic_to_dict(synthesized)
    }

    # ── Save Debug Output ────────────────────────────────────────────────
    logging.info(f"Writing full stage-wise debug output to {output_path}")
    with open(output_path, "w") as f:
        json.dump(stage_results, f, indent=2, default=str)
        
    logging.info("Test complete!")

if __name__ == "__main__":
    run_debug_test()
