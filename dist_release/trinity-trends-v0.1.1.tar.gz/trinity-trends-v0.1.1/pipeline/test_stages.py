import argparse
import json
import logging
import os
import time
from pathlib import Path

# Important: import config first, so we can override it before stages load it
from pipeline import config

from pipeline.models import (
    CollectionScored,
    FinalSynthesisOutput,
    NormalizedItem,
    ScoredItem,
    ClusteredItem,
    ExtractedSignal,
    MergedSignal,
    AnalysisOutput
)


logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger("test_stages")

def pydantic_to_dict(obj):
    if isinstance(obj, list):
        return [pydantic_to_dict(o) for o in obj]
    if isinstance(obj, dict):
        return {k: pydantic_to_dict(v) for k, v in obj.items()}
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    return obj

def dump_stage_data(stage_name: str, data: dict, output_dir: Path):
    out_path = output_dir / f"{stage_name}.json"
    with open(out_path, "w") as f:
        json.dump(data, f, indent=2, default=str)
    logger.info(f"Saved {stage_name} to {out_path}")

def load_stage_data(stage_name: str, output_dir: Path, model_class=None, is_dict=False):
    in_path = output_dir / f"{stage_name}.json"
    if not in_path.exists():
        raise FileNotFoundError(f"Expected input file {in_path} not found. You must run the previous stages first.")
    with open(in_path) as f:
        res = json.load(f).get("results")
        
    if not model_class:
        return res
        
    if is_dict:
        return {int(k): [model_class(**item) for item in v] for k, v in res.items()}
    elif isinstance(res, list):
        return [model_class(**item) for item in res]
    else:
        return model_class(**res)

def main():
    parser = argparse.ArgumentParser(description="Run pipeline stages with tweakable parameters.")
    parser.add_argument("--input", type=str, default=str(config.INPUT_FILE), help="Path to input collection-scored.json")
    parser.add_argument("--output-dir", type=str, default="output/stages", help="Directory to save stage inputs/outputs")
    
    # Stage selection
    parser.add_argument("--start-stage", type=int, default=0, help="Stage to start from (loads previous output)")
    parser.add_argument("--end-stage", type=int, default=9, help="Stage to end at (inclusive)")

    # Tweakable parameters
    parser.add_argument("--min-word-count", type=int, help="Override config.MIN_WORD_COUNT")
    parser.add_argument("--relevance-threshold", type=float, help="Override config.RELEVANCE_THRESHOLD")
    parser.add_argument("--rerank-top-n", type=int, help="Override config.RERANK_TOP_N")
    parser.add_argument("--minhash-threshold", type=float, help="Override config.MINHASH_THRESHOLD")
    parser.add_argument("--mmr-lambda", type=float, help="Override config.MMR_LAMBDA")
    parser.add_argument("--mmr-top-k", type=int, help="Override config.MMR_TOP_K")
    parser.add_argument("--hdbscan-min-size", type=int, help="Override config.HDBSCAN_MIN_CLUSTER_SIZE")
    parser.add_argument("--hdbscan-min-samples", type=int, help="Override config.HDBSCAN_MIN_SAMPLES")
    parser.add_argument("--merge-threshold", type=float, help="Override config.MERGE_SIMILARITY_THRESHOLD")
    parser.add_argument("--min-score", type=float, default=0.0, help="Minimum score for stage 9 synthesize")
    
    args = parser.parse_args()

    # Override config values
    if args.min_word_count is not None: config.MIN_WORD_COUNT = args.min_word_count
    if args.relevance_threshold is not None: config.RELEVANCE_THRESHOLD = args.relevance_threshold
    if args.rerank_top_n is not None: config.RERANK_TOP_N = args.rerank_top_n
    if args.minhash_threshold is not None: config.MINHASH_THRESHOLD = args.minhash_threshold
    if args.mmr_lambda is not None: config.MMR_LAMBDA = args.mmr_lambda
    if args.mmr_top_k is not None: config.MMR_TOP_K = args.mmr_top_k
    if args.hdbscan_min_size is not None: config.HDBSCAN_MIN_CLUSTER_SIZE = args.hdbscan_min_size
    if args.hdbscan_min_samples is not None: config.HDBSCAN_MIN_SAMPLES = args.hdbscan_min_samples
    if args.merge_threshold is not None: config.MERGE_SIMILARITY_THRESHOLD = args.merge_threshold

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    input_path = Path(args.input)
    if not input_path.exists():
        logger.error(f"Input file not found: {input_path}")
        return

    logger.info(f"Loading input from {input_path}")
    with open(input_path) as f:
        raw = json.load(f)
        
    if isinstance(raw, list) and len(raw) > 0:
        raw = raw[0]
        
    data = CollectionScored(**{
        "seed": raw.get("seed_query", raw.get("seed", "")),
        "results": raw.get("output_data", raw.get("results", []))
    })
    
    seed_query = data.seed
    queries = [r.query for r in data.results]
    
    start = args.start_stage
    end = args.end_stage

    if start == 0:
        dump_stage_data("stage_00_raw_input", {"seed_query": seed_query, "data": pydantic_to_dict(data)}, output_dir)
        
    # Variables to pass state between stages
    normalized, scored, reranked, deduped = [], [], [], []
    scored_embeddings = None
    clusters = {}
    extracted, merged, scored_signals = [], [], []
    compressed = None
    all_token_usages = []
    
    # Load required initial state if starting > 0
    try:
        if start == 1: normalized = load_stage_data("stage_0_normalize_output", output_dir, NormalizedItem)
        if start == 2: scored = load_stage_data("stage_1_relevance_output", output_dir, ScoredItem)
        if start == 3: reranked = load_stage_data("stage_2_rerank_output", output_dir, ScoredItem)
        if start == 4:
            deduped = load_stage_data("stage_3_dedup_output", output_dir, ScoredItem)
        if start == 5: clusters = load_stage_data("stage_4_cluster_output", output_dir, ClusteredItem, is_dict=True)
        if start == 6: extracted = load_stage_data("stage_5_extract_output", output_dir, ExtractedSignal)
        if start == 7: merged = load_stage_data("stage_6_merge_output", output_dir, MergedSignal)
        if start == 8: scored_signals = load_stage_data("stage_7_score_output", output_dir, MergedSignal)
        if start == 9: compressed = load_stage_data("stage_8_compress_output", output_dir, AnalysisOutput)
    except FileNotFoundError as e:
        logger.error(str(e))
        return

    # ── Stage 0 ──
    if start <= 0 <= end:
        from pipeline.stages.s0_normalize import normalize
        logger.info("Running Stage 0: Normalize")
        t0 = time.time()
        normalized = normalize(data)
        dump_stage_data("stage_0_normalize_output", {
            "time_sec": round(time.time() - t0, 2), "count": len(normalized), "results": pydantic_to_dict(normalized)
        }, output_dir)
    if start <= 0 <= end and not normalized: return

    # ── Stage 1 ──
    if start <= 1 <= end:
        from pipeline.stages.s1_relevance import relevance_filter
        logger.info("Running Stage 1: Relevance")
        dump_stage_data("stage_1_relevance_input", {"queries": queries, "input_data": pydantic_to_dict(normalized)}, output_dir)
        t1 = time.time()
        scored, scored_embeddings, tu = relevance_filter(normalized, queries)
        if tu: all_token_usages.append(tu)
        import numpy as np
        np.save(output_dir / "stage_1_embeddings.npy", scored_embeddings)
        dump_stage_data("stage_1_relevance_output", {
            "time_sec": round(time.time() - t1, 2), "count": len(scored), "results": pydantic_to_dict(scored), "token_usage": pydantic_to_dict(tu)
        }, output_dir)
    if start <= 1 <= end and not scored: return

    # ── Stage 2 ──
    if start <= 2 <= end:
        # from pipeline.stages.s2_rerank import rerank
        logger.info("Running Stage 2: Rerank (BYPASSED)")
        dump_stage_data("stage_2_rerank_input", {"seed_query": seed_query, "input_data": pydantic_to_dict(scored)}, output_dir)
        t2 = time.time()
        # reranked = rerank(scored, seed_query)
        reranked = scored # Bypassed because gemini-embedding-2 is strong enough
        dump_stage_data("stage_2_rerank_output", {
            "time_sec": round(time.time() - t2, 2), "count": len(reranked), "results": pydantic_to_dict(reranked)
        }, output_dir)
    if start <= 2 <= end and not reranked: return

    # ── Stage 3 ──
    if start <= 3 <= end:
        from pipeline.stages.s3_dedup import dedup_and_diversify
        import numpy as np
        logger.info("Running Stage 3: Dedup")
        
        if start == 3:
            embeddings = np.load(output_dir / "stage_1_embeddings.npy")
        else:
            embeddings = scored_embeddings
        dump_stage_data("stage_3_dedup_input", {
            "embeddings_shape": [len(embeddings), len(embeddings[0]) if len(embeddings) else 0],
            "input_data": pydantic_to_dict(reranked)
        }, output_dir)
        t3 = time.time()
        deduped, deduped_embeddings = dedup_and_diversify(reranked, embeddings)
        dump_stage_data("stage_3_dedup_output", {
            "time_sec": round(time.time() - t3, 2), "count": len(deduped), "results": pydantic_to_dict(deduped)
        }, output_dir)
        np.save(output_dir / "stage_3_embeddings.npy", deduped_embeddings)
    if start <= 3 <= end and not deduped: return

    # ── Stage 4 ──
    if start <= 4 <= end:
        from pipeline.stages.s1_relevance import get_embeddings
        from pipeline.stages.s4_cluster import cluster
        import numpy as np
        logger.info("Running Stage 4: Cluster")
        # Ensure we have embeddings for deduped if we skipped stage 3
        if start == 4:
            try:
                deduped_embeddings = np.load(output_dir / "stage_3_embeddings.npy")
            except Exception:
                logger.warning("stage_3_embeddings.npy not found, falling back to API re-embedding")
                deduped_embeddings, tu = get_embeddings(deduped)
                if tu: all_token_usages.append(tu)
        
        dump_stage_data("stage_4_cluster_input", {"input_data": pydantic_to_dict(deduped)}, output_dir)
        t4 = time.time()
        all_clustered, clusters, noise_items = cluster(deduped, deduped_embeddings)
        dump_stage_data("stage_4_cluster_output", {
            "time_sec": round(time.time() - t4, 2), "cluster_count": len(clusters),
            "results": {str(k): pydantic_to_dict(v) for k, v in clusters.items()},
            "noise_items": pydantic_to_dict(noise_items)
        }, output_dir)
    if start <= 4 <= end and not clusters: return

    # ── Stage 5 ──
    if start <= 5 <= end:
        from pipeline.stages.s5_extract import extract_signals
        logger.info("Running Stage 5: Extract")
        
        # In testing, we might resume from stage 5 and need noise_items
        if start == 5:
            try:
                with open(output_dir / "stage_4_cluster_output.json") as f:
                    cluster_data = json.load(f)
                noise_items = [ClusteredItem(**item) for item in cluster_data.get("noise_items", [])]
            except Exception:
                noise_items = []
        elif start < 5 and 'noise_items' not in locals():
            noise_items = []
            
        dump_stage_data("stage_5_extract_input", {
            "seed_query": seed_query, "input_data": {str(k): pydantic_to_dict(v) for k, v in clusters.items()}
        }, output_dir)
        t5 = time.time()
        extracted, token_usages_s5 = extract_signals(clusters, noise_items, seed_query)
        if token_usages_s5: all_token_usages.extend(token_usages_s5)
        dump_stage_data("stage_5_extract_output", {
            "time_sec": round(time.time() - t5, 2), "count": len(extracted),
            "token_usages": pydantic_to_dict(token_usages_s5), "results": pydantic_to_dict(extracted)
        }, output_dir)
    if start <= 5 <= end and not extracted: return

    # ── Stage 6 ──
    if start <= 6 <= end:
        from pipeline.stages.s6_merge import merge_signals
        logger.info("Running Stage 6: Merge")
        dump_stage_data("stage_6_merge_input", {"input_data": pydantic_to_dict(extracted)}, output_dir)
        t6 = time.time()
        merged = merge_signals(extracted)
        dump_stage_data("stage_6_merge_output", {
            "time_sec": round(time.time() - t6, 2), "count": len(merged), "results": pydantic_to_dict(merged)
        }, output_dir)
    if start <= 6 <= end and not merged: return

    # ── Stage 7 ──
    if start <= 7 <= end:
        from pipeline.stages.s7_score import score_signals
        logger.info("Running Stage 7: Score")
        dump_stage_data("stage_7_score_input", {"input_data": pydantic_to_dict(merged)}, output_dir)
        t7 = time.time()
        scored_signals = score_signals(merged)
        dump_stage_data("stage_7_score_output", {
            "time_sec": round(time.time() - t7, 2), "count": len(scored_signals), "results": pydantic_to_dict(scored_signals)
        }, output_dir)
    if start <= 7 <= end and not scored_signals: return

    # ── Stage 8 ──
    if start <= 8 <= end:
        from pipeline.stages.s8_compress import compress
        logger.info("Running Stage 8: Compress")
        
        total_evidence = 0
        if start <= 0: total_evidence = len(normalized)
        else:
            try:
                # Try to load total_evidence from stage 0 output if it exists
                norm_data = load_stage_data("stage_0_normalize_output", output_dir)
                total_evidence = len(norm_data)
            except FileNotFoundError:
                total_evidence = 100 # Fallback
                
        dump_stage_data("stage_8_compress_input", {
            "seed_query": seed_query, "total_evidence": total_evidence, "input_data": pydantic_to_dict(scored_signals)
        }, output_dir)
        t8 = time.time()
        compressed = compress(scored_signals, seed_query, total_evidence=total_evidence)
        dump_stage_data("stage_8_compress_output", {
            "time_sec": round(time.time() - t8, 2), "results": pydantic_to_dict(compressed)
        }, output_dir)
    if start <= 8 <= end and not compressed: return

    # ── Stage 9 ──
    if start <= 9 <= end:
        from pipeline.stages.s9_synthesize import synthesize_trends
        logger.info("Running Stage 9: Synthesize")
        dump_stage_data("stage_9_synthesize_input", {
            "min_score": args.min_score, "compressed_topic": compressed.topic, "input_data": pydantic_to_dict(compressed)
        }, output_dir)
        t9 = time.time()
        synthesized = synthesize_trends(compressed, min_score=args.min_score)
        if synthesized.token_usage: all_token_usages.extend(synthesized.token_usage)
        dump_stage_data("stage_9_synthesize_output", {
            "time_sec": round(time.time() - t9, 2), "results": pydantic_to_dict(synthesized)
        }, output_dir)
    
    logger.info(f"Test complete! All files saved to {output_dir}")
    
    if all_token_usages:
        logger.info("\n=================================================")
        logger.info("   Total API Token Usage Across Stages")
        logger.info("=================================================")
        total_prompt = sum(u.prompt_tokens for u in all_token_usages)
        total_output = sum(u.output_tokens for u in all_token_usages)
        for u in all_token_usages:
            logger.info(f" - [{u.stage}] Model: {u.model} | Prompt: {u.prompt_tokens} | Output: {u.output_tokens}")
        logger.info("-------------------------------------------------")
        logger.info(f"   Overall Prompt Tokens: {total_prompt}")
        logger.info(f"   Overall Output Tokens: {total_output}")
        logger.info(f"   TOTAL API TOKENS: {total_prompt + total_output}")
        logger.info("=================================================\n")

if __name__ == "__main__":
    main()
